from distutils.core import setup

setup(
	name = 'nester',
	version = '1.0.0',
	py_modules = ['nester'],
	author = 'Young',
	author_email = '',
	url = '',
	description = '',
)
